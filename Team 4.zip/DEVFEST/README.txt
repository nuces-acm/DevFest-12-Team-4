Team Info

Name: Irfan Ul Haq
Email: haq.irfan89@gmail.com
Mobile: 03455225983

Name: Muhammad Waseem Afzal
Email: waseemafzal825@gmail.com
Mobile: 03025474347

Name: Muhammad Zulqarnain
Email: zulqarnain_mian@ymail.com
Mobile: 03466641508

Abstract:

To solve the problem where acquiring the exact location of any person is not possible due to the absence of GPS based smart phones we created a system which recieves the physical address of any person via SMS which can translate the address into approximate latitude and longitude and can plot this information on a map.
It can further be used to report diseases, building patients information set based on their location and disease, helping patients in providing them the information related to the disease, nearest hospitals and doctors. 
Syatem can also track the concentration of disease in any area and can generate the alrets for concerned authorities incase of any threshhold crossed.