<!--Style sheet for footer-->
<style>
.c
{ color:#F00;}
#footer {
   position:fixed;
clear: both;
   bottom:0;
   width:99%; 

}
</style>
<br>
<div align="center" id="footer">
  <p><sub>SMS Based Location Aware Data Builder v. 1.0<br>
    </sub><sub>Powered by OIZ</sub> </p>
  </div>